﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxColliderCS : MonoBehaviour
{
	public bool isTrigger=false;
	public Vector3 center = Vector3.zero;
	public Vector3 size = Vector3.one;
	public Vector3 length = Vector3.one;

	[HideInInspector]
	public float maxLength=0;
	[HideInInspector]
	public Vector3 centerPosition;

	private bool isStatic;
	public Vector3[] points;


	private void Awake()
	{
		

		if (GetComponent<RigidbodyCS>())
			isStatic = false;
		else
			isStatic = true;


		points = new Vector3[8];
		if (isStatic)
			SetBoundaryPoint();

		foreach (var p in points)
		{
			if (maxLength < (p - centerPosition).magnitude)
				maxLength = (p - centerPosition).magnitude;
		}
	}

	void Start()
	{

	}

	void FixedUpdate()
	{
		if (!isStatic)
			SetBoundaryPoint();
	}


	void SetBoundaryPoint()
	{
		centerPosition = this.transform.position + center;
		length = new Vector3(size.x * this.transform.localScale.x,
							size.y * this.transform.localScale.y,
							size.z * this.transform.localScale.z) / 2;

		for (int i = 0; i<points.Length; i++)
		{
			int a, b, c;
			a = i % 8 >= 4 ? 1 : -1;
			b = i % 4 >= 2 ? 1 : -1;
			c = i % 2 >= 1 ? 1 : -1;

			points[i] = centerPosition + new Vector3(size.x * this.transform.localScale.x *a,
													size.y * this.transform.localScale.y *b,
													size.z * this.transform.localScale.z *c) / 2;

		}
		
	}


	public bool CheckCollision(RigidbodyCS rigid, out Vector3 dir)
	{
		bool result = false;
		Vector3 resultDir = Vector3.zero;

		Vector3 distance = this.transform.position - rigid.gameObject.transform.position;
		float distanceX = length.x + rigid.colliderCS.length.x;
		float distanceY = length.y + rigid.colliderCS.length.y;
		float distanceZ = length.z + rigid.colliderCS.length.z;

		if(Mathf.Abs(distance.x) <= distanceX && Mathf.Abs(distance.y) <= distanceY && Mathf.Abs(distance.z) <= distanceZ)
		{
			result = true;
			float[] dirDot = { Vector3.Dot(this.transform.up, rigid.velocity),
								Vector3.Dot(-this.transform.up, rigid.velocity),
								Vector3.Dot(this.transform.right, rigid.velocity),
								Vector3.Dot(-this.transform.right, rigid.velocity),
								Vector3.Dot(this.transform.forward, rigid.velocity),
								Vector3.Dot(-this.transform.forward, rigid.velocity) };

			int index = -1;
			for(int i = 0; i<dirDot.Length-1; i++)
			{
				if (dirDot[i] < dirDot[i + 1])
					index = i;
			}

			switch (index)
			{
				case 1:
					resultDir = this.transform.up;
					break;
				case 2:
					resultDir = -this.transform.up;
					break;
				case 3:
					resultDir = this.transform.right;
					break;
				case 4:
					resultDir = -this.transform.right;
					break;
				case 5:
					resultDir = this.transform.forward;
					break;
				case 6:
					resultDir = -this.transform.forward;
					break;
			}

			//Debug.Log(result+" : "+ distance+ " / " + distanceX + "," + distanceY + "," + distanceZ + " / ");
		}


		dir = resultDir;
		return result;
	}
}
