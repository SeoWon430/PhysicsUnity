﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RigidbodyCS : MonoBehaviour
{
	public float mass=1;
	public bool useGravity=true;
	public bool isKinematic=false;
	
	[HideInInspector]
	public Vector3 velocity;
	[HideInInspector]
	public Vector3 Acceleration;
	[HideInInspector]
	public BoxColliderCS colliderCS;

	//public List<GameObject> contactObjects;
	public Dictionary<GameObject, Vector3> contactObjects;

	private void Awake()
	{
		velocity = Vector3.zero;
		if (mass <= 0)
			mass = 1;

		colliderCS = GetComponent<BoxColliderCS>();
		if (!colliderCS)
			colliderCS = this.gameObject.AddComponent<BoxColliderCS>();

		contactObjects = new Dictionary<GameObject, Vector3>();
	}


	void Start()
	{

	}

	void FixedUpdate()
	{
		if (useGravity)
		{
			AddForce(Physics.gravity);
		}



	}
	private void LateUpdate()
	{
		if (contactObjects.Count > 0)
			foreach (Vector3 force in contactObjects.Values)
			{
				AddForce(Acceleration.magnitude * force);
			}

		if (velocity.magnitude > 0.01f)
		{
			VelocityMove();
		}


	}


	private void VelocityMove()
	{
		this.transform.position += velocity * Time.deltaTime;
	}

	public void AddForce(Vector3 force)
	{
		//Debug.Log(force);
		Acceleration += force / mass;
		velocity = Acceleration * Time.deltaTime;
		//힘을 받을떄 회전량 추가
	}

	

}
