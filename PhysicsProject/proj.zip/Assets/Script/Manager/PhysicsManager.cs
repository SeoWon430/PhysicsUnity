﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhysicsManager : MonoBehaviour
{
	public List<BoxColliderCS> colliderList;
	public List<RigidbodyCS> rigidbodyList;


	void Start()
	{
		RigidbodyCS[] rigids = FindObjectsOfType<RigidbodyCS>();
		foreach (var r in rigids)
		{
			rigidbodyList.Add(r);
		}

		BoxColliderCS[] colls = FindObjectsOfType<BoxColliderCS>();
		foreach(var c in colls)
		{
			bool check=true;

			foreach (var r in rigids)
			{
				if (c.gameObject.Equals(r.gameObject))
				{
					check = false;
					break;
				}
			}
			if(check)
				colliderList.Add(c);
		}

	}
	
    void FixedUpdate()
    {
		//maxSizeLength;
		foreach( var rigidObject in rigidbodyList)
		{
			foreach(var collObject in colliderList)
			{
				Vector3 forceDirection = Vector3.zero;
				bool isCollision = collObject.CheckCollision(rigidObject, out forceDirection);
				bool isContain = rigidObject.contactObjects.ContainsKey(collObject.gameObject);

				if (isCollision)
				{
					//rigidObject.AddForce(rigidObject.Acceleration.magnitude * forceDirection);

					if(!isContain)
						rigidObject.contactObjects.Add(collObject.gameObject, forceDirection);
				}
				else if (!isCollision && isContain)
				{
					rigidObject.contactObjects.Remove(collObject.gameObject);
				}


			}
		}

	}
}
